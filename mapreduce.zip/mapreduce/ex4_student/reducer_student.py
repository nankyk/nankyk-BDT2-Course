#!/usr/bin/env python

from operator import itemgetter
import sys

current_key = None
max = 0
count = 0
 
# input comes from STDIN    
 
for line in sys.stdin:
    # remove leading and trailing whitespace
    line = line.strip()
    row = line.split("\t")
    (key,value) = row
 
    try: 
        value = int(value)
    except ValueError:
        continue
 
    if current_key == (key):
        max = value
 
    else:
        if current_key:
             # write result to STDOUT
            print('{}\t{}'.format(current_key,float(max))
        current_key = key
        max = value
 
if current_key == key:
    print('{}\t{}'.format(current_key,float(max))